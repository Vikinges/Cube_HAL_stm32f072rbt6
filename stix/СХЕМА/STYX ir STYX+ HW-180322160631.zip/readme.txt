Project name: STYX Plus v1.9

Important notes for Manufacture:
- PCB layers: 4 layers
- PCB Thickness: standart
- Panel size: 201.2 mm x 144.0 mm
- 1x board size: 100.6 mm x 62.0 mm
- Boards in Panel: 4 pcs

